﻿// Grade ID: R8206
// Program #1
// Due : Feb 11, 2020
// Section 01
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project1form
{
    public partial class CarpetEstimatorForm : Form
    {
        public CarpetEstimatorForm()
        {
            InitializeComponent();
        }
        // This event handles the calculation of square yards needeed, carpet cost, padding cost, labor cost, and total cost from a users given input.
        private void button1_Click(object sender, EventArgs e)
        {
            double width; 
            double length;
            double carpetprice;
            int layers;
            double room;
            const double yardconversion = 9; // yard conversion
            const double laborprice = 4.25; // labor cost per sq. yrd
            const double paddingprice = 2.50; // padding price per sq. yrd
            const double firstroombonus = 75.00; // first room price
            const double extra = 1.1; // 10% extra for waste

            width = double.Parse(WidthInput.Text); // converting user inputs
            length = double.Parse(LengthInput.Text);
            carpetprice = double.Parse(SquareYardInput.Text);
            layers = int.Parse(LayersInput.Text);
            room = double.Parse(RoomInput.Text);

            double sqyrdtotal = (width * length) / yardconversion; // calculates area
            double carpetcost = (carpetprice * sqyrdtotal) * extra; // calculates carpet cost
            double paddingcost = (sqyrdtotal * paddingprice * layers) * extra ; // calculates padding cost
            double laborcost = (laborprice * sqyrdtotal)+(firstroombonus * room); // calculated labor cost
            double totalcost = (carpetcost + paddingcost + laborcost); // calculates total cost

            SquareYardsOutput.Text = (sqyrdtotal.ToString("N1")); // Writes out outputs for calulations
            CarpetCostOutput.Text = (carpetcost.ToString("C"));
            PaddingOutput.Text = (paddingcost.ToString("C"));
            LaborCostOutput.Text = (laborcost.ToString("C"));
            TotalCostOutput.Text = (totalcost.ToString("C"));  

        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void SquareYardInput_Click(object sender, EventArgs e)
        {

        }
    }
}
