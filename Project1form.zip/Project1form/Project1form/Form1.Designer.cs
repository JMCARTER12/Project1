﻿namespace Project1form
{
    partial class CarpetEstimatorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Title1 = new System.Windows.Forms.TextBox();
            this.WidthTxt = new System.Windows.Forms.Label();
            this.LengthTxt = new System.Windows.Forms.Label();
            this.SquareYardTxt = new System.Windows.Forms.Label();
            this.LayersTxt = new System.Windows.Forms.Label();
            this.RoomTxt = new System.Windows.Forms.Label();
            this.PaddingOutput = new System.Windows.Forms.Label();
            this.SquareYardsOutput = new System.Windows.Forms.Label();
            this.CarpetCostOutput = new System.Windows.Forms.Label();
            this.LaborCostOutput = new System.Windows.Forms.Label();
            this.TotalCostOutput = new System.Windows.Forms.Label();
            this.CalculateBtn = new System.Windows.Forms.Button();
            this.WidthInput = new System.Windows.Forms.TextBox();
            this.LengthInput = new System.Windows.Forms.TextBox();
            this.SquareYardInput = new System.Windows.Forms.TextBox();
            this.LayersInput = new System.Windows.Forms.TextBox();
            this.RoomInput = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Title1
            // 
            this.Title1.BackColor = System.Drawing.SystemColors.Menu;
            this.Title1.Cursor = System.Windows.Forms.Cursors.No;
            this.Title1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Title1.Location = new System.Drawing.Point(72, 12);
            this.Title1.Name = "Title1";
            this.Title1.ReadOnly = true;
            this.Title1.Size = new System.Drawing.Size(369, 26);
            this.Title1.TabIndex = 0;
            this.Title1.Text = "Welcome to the Handy-Dandy Carpet Estimator";
            this.Title1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // WidthTxt
            // 
            this.WidthTxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.WidthTxt.Location = new System.Drawing.Point(72, 58);
            this.WidthTxt.Name = "WidthTxt";
            this.WidthTxt.Size = new System.Drawing.Size(203, 23);
            this.WidthTxt.TabIndex = 1;
            this.WidthTxt.Text = "Enter the max width of room ( in feet ) :";
            this.WidthTxt.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // LengthTxt
            // 
            this.LengthTxt.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.LengthTxt.Location = new System.Drawing.Point(72, 97);
            this.LengthTxt.Name = "LengthTxt";
            this.LengthTxt.Size = new System.Drawing.Size(203, 23);
            this.LengthTxt.TabIndex = 2;
            this.LengthTxt.Text = "Enter the max length of room ( in feet ) :";
            this.LengthTxt.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // SquareYardTxt
            // 
            this.SquareYardTxt.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.SquareYardTxt.Location = new System.Drawing.Point(72, 134);
            this.SquareYardTxt.Name = "SquareYardTxt";
            this.SquareYardTxt.Size = new System.Drawing.Size(203, 23);
            this.SquareYardTxt.TabIndex = 3;
            this.SquareYardTxt.Text = "Enter the carpet price ( per sq. yard ) :";
            this.SquareYardTxt.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.SquareYardTxt.Click += new System.EventHandler(this.SquareYardInput_Click);
            // 
            // LayersTxt
            // 
            this.LayersTxt.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.LayersTxt.Location = new System.Drawing.Point(72, 172);
            this.LayersTxt.Name = "LayersTxt";
            this.LayersTxt.Size = new System.Drawing.Size(203, 23);
            this.LayersTxt.TabIndex = 4;
            this.LayersTxt.Text = "Enter layers of padding used ( 1 or 2 ) :";
            this.LayersTxt.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // RoomTxt
            // 
            this.RoomTxt.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.RoomTxt.Location = new System.Drawing.Point(72, 213);
            this.RoomTxt.Name = "RoomTxt";
            this.RoomTxt.Size = new System.Drawing.Size(203, 23);
            this.RoomTxt.TabIndex = 5;
            this.RoomTxt.Text = "Is this the first room? ( 1 = Yes, 0 = No ):";
            this.RoomTxt.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // PaddingOutput
            // 
            this.PaddingOutput.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.PaddingOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PaddingOutput.Location = new System.Drawing.Point(283, 395);
            this.PaddingOutput.Name = "PaddingOutput";
            this.PaddingOutput.Size = new System.Drawing.Size(100, 23);
            this.PaddingOutput.TabIndex = 6;
            // 
            // SquareYardsOutput
            // 
            this.SquareYardsOutput.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.SquareYardsOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SquareYardsOutput.Location = new System.Drawing.Point(283, 319);
            this.SquareYardsOutput.Name = "SquareYardsOutput";
            this.SquareYardsOutput.Size = new System.Drawing.Size(100, 23);
            this.SquareYardsOutput.TabIndex = 7;
            // 
            // CarpetCostOutput
            // 
            this.CarpetCostOutput.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.CarpetCostOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.CarpetCostOutput.Location = new System.Drawing.Point(283, 356);
            this.CarpetCostOutput.Name = "CarpetCostOutput";
            this.CarpetCostOutput.Size = new System.Drawing.Size(100, 23);
            this.CarpetCostOutput.TabIndex = 8;
            // 
            // LaborCostOutput
            // 
            this.LaborCostOutput.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.LaborCostOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LaborCostOutput.Location = new System.Drawing.Point(283, 433);
            this.LaborCostOutput.Name = "LaborCostOutput";
            this.LaborCostOutput.Size = new System.Drawing.Size(100, 23);
            this.LaborCostOutput.TabIndex = 9;
            // 
            // TotalCostOutput
            // 
            this.TotalCostOutput.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.TotalCostOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TotalCostOutput.Location = new System.Drawing.Point(283, 474);
            this.TotalCostOutput.Name = "TotalCostOutput";
            this.TotalCostOutput.Size = new System.Drawing.Size(100, 23);
            this.TotalCostOutput.TabIndex = 10;
            // 
            // CalculateBtn
            // 
            this.CalculateBtn.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.CalculateBtn.Location = new System.Drawing.Point(140, 254);
            this.CalculateBtn.Name = "CalculateBtn";
            this.CalculateBtn.Size = new System.Drawing.Size(243, 44);
            this.CalculateBtn.TabIndex = 11;
            this.CalculateBtn.Text = "Calculate!";
            this.CalculateBtn.UseVisualStyleBackColor = false;
            this.CalculateBtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // WidthInput
            // 
            this.WidthInput.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.WidthInput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.WidthInput.Location = new System.Drawing.Point(341, 61);
            this.WidthInput.Name = "WidthInput";
            this.WidthInput.Size = new System.Drawing.Size(100, 20);
            this.WidthInput.TabIndex = 12;
            // 
            // LengthInput
            // 
            this.LengthInput.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.LengthInput.Location = new System.Drawing.Point(341, 100);
            this.LengthInput.Name = "LengthInput";
            this.LengthInput.Size = new System.Drawing.Size(100, 20);
            this.LengthInput.TabIndex = 13;
            // 
            // SquareYardInput
            // 
            this.SquareYardInput.Location = new System.Drawing.Point(341, 137);
            this.SquareYardInput.Name = "SquareYardInput";
            this.SquareYardInput.Size = new System.Drawing.Size(100, 20);
            this.SquareYardInput.TabIndex = 14;
            // 
            // LayersInput
            // 
            this.LayersInput.Location = new System.Drawing.Point(341, 175);
            this.LayersInput.Name = "LayersInput";
            this.LayersInput.Size = new System.Drawing.Size(100, 20);
            this.LayersInput.TabIndex = 15;
            // 
            // RoomInput
            // 
            this.RoomInput.Location = new System.Drawing.Point(341, 216);
            this.RoomInput.Name = "RoomInput";
            this.RoomInput.Size = new System.Drawing.Size(100, 20);
            this.RoomInput.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(140, 329);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 13);
            this.label1.TabIndex = 17;
            this.label1.Text = "Sq. Yards Needed:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(140, 366);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 13);
            this.label2.TabIndex = 18;
            this.label2.Text = "Carpet Cost:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(140, 405);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 13);
            this.label3.TabIndex = 19;
            this.label3.Text = "Padding Cost:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(140, 443);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 13);
            this.label4.TabIndex = 20;
            this.label4.Text = "Labor Cost:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(140, 484);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 13);
            this.label5.TabIndex = 21;
            this.label5.Text = "Total Cost:";
            // 
            // CarpetEstimatorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(525, 516);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.RoomInput);
            this.Controls.Add(this.LayersInput);
            this.Controls.Add(this.SquareYardInput);
            this.Controls.Add(this.LengthInput);
            this.Controls.Add(this.WidthInput);
            this.Controls.Add(this.CalculateBtn);
            this.Controls.Add(this.TotalCostOutput);
            this.Controls.Add(this.LaborCostOutput);
            this.Controls.Add(this.CarpetCostOutput);
            this.Controls.Add(this.SquareYardsOutput);
            this.Controls.Add(this.PaddingOutput);
            this.Controls.Add(this.RoomTxt);
            this.Controls.Add(this.LayersTxt);
            this.Controls.Add(this.SquareYardTxt);
            this.Controls.Add(this.LengthTxt);
            this.Controls.Add(this.WidthTxt);
            this.Controls.Add(this.Title1);
            this.Name = "CarpetEstimatorForm";
            this.Text = "CarpetEstimatorCalculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Title1;
        private System.Windows.Forms.Label WidthTxt;
        private System.Windows.Forms.Label LengthTxt;
        private System.Windows.Forms.Label SquareYardTxt;
        private System.Windows.Forms.Label LayersTxt;
        private System.Windows.Forms.Label RoomTxt;
        private System.Windows.Forms.Label PaddingOutput;
        private System.Windows.Forms.Label SquareYardsOutput;
        private System.Windows.Forms.Label CarpetCostOutput;
        private System.Windows.Forms.Label LaborCostOutput;
        private System.Windows.Forms.Label TotalCostOutput;
        private System.Windows.Forms.Button CalculateBtn;
        private System.Windows.Forms.TextBox WidthInput;
        private System.Windows.Forms.TextBox LengthInput;
        private System.Windows.Forms.TextBox SquareYardInput;
        private System.Windows.Forms.TextBox LayersInput;
        private System.Windows.Forms.TextBox RoomInput;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}

